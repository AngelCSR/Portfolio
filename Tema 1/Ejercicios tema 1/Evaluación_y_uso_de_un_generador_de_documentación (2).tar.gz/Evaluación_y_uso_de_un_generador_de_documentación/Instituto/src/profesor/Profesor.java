/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package profesor;

import dni.Dni;
import java.text.ParseException;
import java.util.ArrayList;
import persona.Persona;
import modulo.Modulo;
/**
 *
 * @author usutarde
 */
/**
 * Representa a un profesor, extendiendo la funcionalidad de la clase {@link Persona}
 * para incluir información específica del profesor como el departamento al que pertenece
 * y la lista de módulos que imparte.
 * Cumple con las convenciones de nombres de Java y está documentada para JavaDOC.
 *
 * @author usutarde
 * @version 1.0
 */
public class Profesor extends Persona {
    /**
     * Departamento al que pertenece el profesor.
     */
    private String departamento;
    /**
     * Lista de módulos que imparte el profesor.
     */
    private ArrayList<Modulo> modulos = new ArrayList<>();

    /**
     * Constructor de la clase {@code Profesor}.
     *
     * @param nombre       Nombre del profesor.
     * @param apellido1    Primer apellido del profesor.
     * @param apellido2    Segundo apellido del profesor.
     * @param numero       Número del DNI del profesor.
     * @param letra        Letra del DNI del profesor.
     * @param departamento Departamento al que pertenece el profesor.
     * @throws ParseException Si ocurre un error al parsear la información relacionada con la persona.
     */
    public Profesor(String nombre, String apellido1, String apellido2, int numero, char letra, String departamento) 
            throws ParseException {
        super(nombre, apellido1, apellido2, numero, letra);
        this.departamento = departamento;
    }

    /**
     * Constructor de la clase {@code Profesor} sin especificar el departamento.
     *
     * @param nombre    Nombre del profesor.
     * @param apellido1 Primer apellido del profesor.
     * @param apellido2 Segundo apellido del profesor.
     * @param numero    Número del DNI del profesor.
     * @param letra     Letra del DNI del profesor.
     * @throws ParseException Si ocurre un error al parsear la información relacionada con la persona.
     */
    public Profesor(String nombre, String apellido1, String apellido2, int numero, char letra) throws ParseException {
        super(nombre, apellido1, apellido2, numero, letra);
    }

    /**
     * Obtiene el departamento al que pertenece el profesor.
     *
     * @return El departamento del profesor.
     */
    public String getDepartamento() {
        return departamento;
    }

    /**
     * Establece el departamento al que pertenece el profesor.
     *
     * @param departamento El nuevo departamento del profesor.
     */
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    /**
     * Inserta un módulo en la lista de módulos que imparte el profesor
     * y establece la referencia del profesor en el módulo.
     *
     * @param mod El módulo a insertar.
     */
    public void insertarModulo(Modulo mod) {
        this.modulos.add(mod);
        mod.setProfesor(this);
    }

    /**
     * Devuelve una representación en cadena del objeto {@code Profesor}.
     * Incluye la información de la superclase {@link Persona} y el departamento del profesor (si está asignado).
     *
     * @return Una cadena que representa al profesor.
     * @see Persona#toString()
     * @see #getDepartamento()
     */
    @Override
    public String toString() {
        if (this.departamento != null) {
            return super.toString() + " departamento: " + departamento;
        } else {
            return super.toString();
        }
    }
}
