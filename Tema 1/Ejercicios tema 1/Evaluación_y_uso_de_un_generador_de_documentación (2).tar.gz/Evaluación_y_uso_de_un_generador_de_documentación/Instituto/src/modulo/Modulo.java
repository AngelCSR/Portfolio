/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
 

package modulo;

import ciclo.Ciclo;
import profesor.Profesor;

/**
 *
 * @author usutarde
 */
public class Modulo {
    /**
     * Código único que identifica el módulo.
     */
    private int codigo;
    /**
     * Nombre del módulo.
     */
    private String nombre;
    /**
     * Ciclo formativo al que pertenece el módulo.
     */
    private Ciclo ciclo;
    /**
     * Profesor que imparte el módulo.
     */
    private Profesor profesor;

    /**
     * Constructor de la clase Modulo.
     *
     * @param codigo Código único del módulo.
     * @param nombre Nombre del módulo.
     * @param ciclo  Ciclo formativo al que pertenece el módulo.
     */
    public Modulo(int codigo, String nombre, Ciclo ciclo) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.ciclo = ciclo;
    }

    /**
     * Constructor de la clase Modulo.
     *
     * @param codigo   Código único del módulo.
     * @param nombre   Nombre del módulo.
     * @param ciclo    Ciclo formativo al que pertenece el módulo.
     * @param profesor Profesor que imparte el módulo.
     */
    public Modulo(int codigo, String nombre, Ciclo ciclo, Profesor profesor) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.ciclo = ciclo;
        this.profesor = profesor;
    }

    /**
     * Constructor de la clase Modulo.
     *
     * @param codigo   Código único del módulo.
     * @param nombre   Nombre del módulo.
     * @param profesor Profesor que imparte el módulo.
     */
    public Modulo(int codigo, String nombre, Profesor profesor) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.profesor = profesor;
    }

    /**
     * Constructor de la clase Modulo.
     *
     * @param codigo Código único del módulo.
     * @param nombre Nombre del módulo.
     */
    public Modulo(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    /**
     * Obtiene el código del módulo.
     *
     * @return El código del módulo.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Establece el código del módulo.
     *
     * @param codigo El nuevo código del módulo.
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Obtiene el nombre del módulo.
     *
     * @return El nombre del módulo.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del módulo.
     *
     * @param nombre El nuevo nombre del módulo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el ciclo formativo al que pertenece el módulo.
     *
     * @return El ciclo formativo del módulo.
     */
    public Ciclo getCiclo() {
        return ciclo;
    }

    /**
     * Establece el ciclo formativo al que pertenece el módulo.
     *
     * @param ciclo El nuevo ciclo formativo del módulo.
     */
    public void setCiclo(Ciclo ciclo) {
        this.ciclo = ciclo;
    }

    /**
     * Obtiene el profesor que imparte el módulo.
     *
     * @return El profesor del módulo.
     */
    public Profesor getProfesor() {
        return profesor;
    }

    /**
     * Establece el profesor que imparte el módulo.
     *
     * @param profesor El nuevo profesor del módulo.
     */
    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }
 
    /**
     * Devuelve una representación en cadena del objeto Modulo.
     * Muestra el código del módulo, el nombre, el código del ciclo
     * y la información del profesor si está asignado.
     *
     * @return Una cadena con la información del módulo.
     */

    @Override
    public String toString() {
        if (this.profesor != null) {
            
       
        return  System.lineSeparator()+"Código de Modulo : " + codigo + System.lineSeparator()+
                "Nombre: " + nombre + System.lineSeparator()
                + "Codigo de Ciclo: " + ciclo.getCodigo() + System.lineSeparator()+
                "Profesor: " + profesor.toString()+ System.lineSeparator() ;
         } else
            return  System.lineSeparator()+"Código de Modulo : " + codigo + System.lineSeparator()+
                "Nombre: " + nombre + System.lineSeparator()
                +"Codigo de Ciclo: " + ciclo.getCodigo() + System.lineSeparator()
                + "Profesor: No asignado " + System.lineSeparator() ;
    }
    
    
}
