/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persona;

import dni.Dni;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.LocalDate;
import java.time.Period;

/**
 * Representa a una persona con su nombre, apellidos, fecha de nacimiento y DNI.
 * Esta clase sigue las convenciones de nombres de Java y está documentada para JavaDOC.
 *
 * @author Ángel Campo
 * @version 1.0
 */
public class Persona {

    /**
     * Nombre de la persona.
     */
    private String nombre;

    /**
     * Primer apellido de la persona.
     */
    private String apellido1;

    /**
     * Segundo apellido de la persona.
     */
    private String apellido2;

    /**
     * Fecha de nacimiento de la persona.
     */
    private Date fechaNacimiento;

    /**
     * Objeto Dni que contiene el número y la letra del Documento Nacional de Identidad.
     */
    private Dni dni;

  /**
     * Constructor de la clase Persona que recibe los datos como parámetros.
     * La fecha de nacimiento se recibe como String y se convierte a objeto Date.
     *
     * @param nombre             Nombre de la persona.
     * @param apellido1          Primer apellido de la persona.
     * @param apellido2          Segundo apellido de la persona.
     * @param fechaNacimientoStr Fecha de nacimiento de la persona en formato "dd/MM/yyyy".
     * @param numeroDni          Número del Documento Nacional de Identidad.
     * @param letraDni           Letra del Documento Nacional de Identidad.
     * @throws ParseException Si la cadena de fecha de nacimiento no tiene el formato esperado.
     */
    public Persona(String nombre, String apellido1, String apellido2, String fechaNacimientoStr, int numeroDni, char letraDni) throws ParseException {
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        setFechaNacimiento(fechaNacimientoStr); // Usar el método setFechaNacimiento para la conversión
        this.dni = new Dni(numeroDni, letraDni);
    }

    /**
     * Constructor de la clase Persona que recibe los datos como parámetros, incluyendo el número y letra del DNI.
     * No establece la fecha de nacimiento.
     *
     * @param nombre    Nombre de la persona.
     * @param apellido1 Primer apellido de la persona.
     * @param apellido2 Segundo apellido de la persona.
     * @param numeroDni Número del Documento Nacional de Identidad.
     * @param letraDni  Letra del Documento Nacional de Identidad.
     * @throws ParseException Si ocurre un error al crear el objeto Dni.
     */
    public Persona(String nombre, String apellido1, String apellido2, int numeroDni, char letraDni) throws ParseException {
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.dni = new Dni(numeroDni, letraDni);
    }

    /**
     * Constructor de la clase Persona que recibe los datos como parámetros, incluyendo el objeto Dni.
     * No establece la fecha de nacimiento.
     *
     * @param nombre    Nombre de la persona.
     * @param apellido1 Primer apellido de la persona.
     * @param apellido2 Segundo apellido de la persona.
     * @param dni       Objeto Dni de la persona.
     */
    public Persona(String nombre, String apellido1, String apellido2, Dni dni) {
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.dni = dni;
    }
    

    /**
     * Obtiene el nombre de la persona.
     *
     * @return El nombre de la persona.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre de la persona.
     *
     * @param nombre El nuevo nombre de la persona.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el primer apellido de la persona.
     *
     * @return El primer apellido de la persona.
     */
    public String getApellido1() {
        return apellido1;
    }

    /**
     * Establece el primer apellido de la persona.
     *
     * @param apellido1 El nuevo primer apellido de la persona.
     */
    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    /**
     * Obtiene el segundo apellido de la persona.
     *
     * @return El segundo apellido de la persona.
     */
    public String getApellido2() {
        return apellido2;
    }

    /**
     * Establece el segundo apellido de la persona.
     *
     * @param apellido2 El nuevo segundo apellido de la persona.
     */
    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    /**
     * Obtiene el objeto Dni de la persona.
     *
     * @return El objeto Dni de la persona.
     */
    public Dni getDni() {
        return dni;
    }

    /**
     * Establece el objeto Dni de la persona.
     *
     * @param dni El nuevo objeto Dni de la persona.
     */
    public void setDni(Dni dni) {
        this.dni = dni;
    }

    /**
     * Obtiene la fecha de nacimiento de la persona como una cadena en formato "dd/MM/yyyy".
     *
     * @return La fecha de nacimiento de la persona en formato "dd/MM/yyyy".
     */
    public String getFechaNacimiento() {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        return formatoFecha.format(fechaNacimiento);
    }

    /**
     * Establece la fecha de nacimiento de la persona a partir de una cadena en formato "dd/MM/yyyy".
     *
     * @param fechaEntra La fecha de nacimiento de la persona en formato "dd/MM/yyyy".
     * @throws ParseException Si la cadena de fecha de nacimiento no tiene el formato esperado.
     */
    public void setFechaNacimiento(String fechaEntra) throws ParseException {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        this.fechaNacimiento = formatoFecha.parse(fechaEntra);
    }

    /**
     * Calcula la edad de la persona basándose en su fecha de nacimiento.
     *
     * @return La edad de la persona en años.
     */
    public int getEdad() {
        // Convertir Date a LocalDate para facilitar el cálculo de la edad
        LocalDate fechaNac = new java.sql.Date(fechaNacimiento.getTime()).toLocalDate();
        LocalDate hoy = LocalDate.now();

        // Calcular la diferencia en años utilizando la clase Period
        return Period.between(fechaNac, hoy).getYears();
    }

    /**
     * Devuelve una representación en cadena de la persona, incluyendo su nombre completo, edad y DNI.
     *
     * @return Una cadena con el nombre, apellidos, edad y DNI de la persona.
     * @see #getNombre()
     * @see #getApellido1()
     * @see #getApellido2()
     * @see #getEdad()
     * @see #getDni()
     */
    @Override
    public String toString() {
        return nombre + " " + apellido1 + " " + apellido2 + ", dni: " + dni.getNumero()+"-"+dni.getLetra() ;
    }
}
