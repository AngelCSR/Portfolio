/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ciclo;

import alumno.Alumno;
import modulo.Modulo;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Representa un ciclo formativo con su código, nombre, lista de módulos y lista de alumnos.
 * Cumple con las convenciones de nombres de Java y está documentada para JavaDOC.
 *
 * @author usutarde
 * @version 1.0
 */
public class Ciclo {
    /**
     * Código único que identifica el ciclo formativo.
     */
    private int codigo;
    /**
     * Nombre del ciclo formativo.
     */
    private String nombre;
    /**
     * Lista de módulos que pertenecen a este ciclo formativo.
     */
    private ArrayList<Modulo> modulos = new ArrayList<>();
    /**
     * Lista de alumnos matriculados en este ciclo formativo.
     */
    private ArrayList<Alumno> alumnos = new ArrayList<>();

    /**
     * Constructor de la clase {@code Ciclo}.
     *
     * @param codigo Código único del ciclo formativo.
     * @param nombre Nombre del ciclo formativo.
     */
    public Ciclo(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    /**
     * Obtiene la lista de módulos del ciclo formativo.
     *
     * @return La lista de módulos.
     */
    public ArrayList<Modulo> getModulos() {
        return modulos;
    }

    /**
     * Establece la lista de módulos del ciclo formativo.
     *
     * @param modulos La nueva lista de módulos.
     */
    public void setModulos(ArrayList<Modulo> modulos) {
        this.modulos = modulos;
    }

    /**
     * Obtiene el código del ciclo formativo.
     *
     * @return El código del ciclo.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Establece el código del ciclo formativo.
     *
     * @param codigo El nuevo código del ciclo.
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Obtiene el nombre del ciclo formativo.
     *
     * @return El nombre del ciclo.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del ciclo formativo.
     *
     * @param nombre El nuevo nombre del ciclo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Inserta un módulo en la lista de módulos del ciclo y establece la referencia del ciclo en el módulo.
     *
     * @param mod El módulo a insertar.
     */
    public void insertarModulo(Modulo mod) {
        this.modulos.add(mod);
        mod.setCiclo(this);
    }

    /**
     * Muestra en la consola el listado de módulos pertenecientes a este ciclo formativo.
     */
    public void mostrarModulo() {
        System.out.println("Listado de módulos del ciclo : " + getNombre());
        Iterator<Modulo> it = modulos.iterator();
        while (it.hasNext()) {
            Modulo elemento = it.next();
            System.out.println(elemento.toString());
        }
    }

    /**
     * Inserta un alumno en la lista de alumnos matriculados en este ciclo y establece la referencia 
     * del ciclo en el alumno.
     *
     * @param alu El alumno a insertar.
     */
    public void insertarAlumno(Alumno alu) {
        this.alumnos.add(alu);
        alu.setCiclo(this);
    }

    /**
     * Muestra en la consola el listado de alumnos matriculados en este ciclo formativo.
     */
    public void mostrarAlumno() {
        System.out.println("Listado de alumnos del ciclo : " + getNombre());
        Iterator<Alumno> it = alumnos.iterator();
        while (it.hasNext()) {
            Alumno elemento = it.next();
            System.out.println(elemento.toString());
        }
    }

    /**
     * Devuelve una representación en cadena del objeto {@code Ciclo}.
     * Muestra el código y el nombre del ciclo formativo.
     *
     * @return Una cadena que representa el ciclo formativo.
     */
    @Override
    public String toString() {
        return "Ciclo: " + " codigo de l ciclo " + codigo + ", nombre del ciclo " + nombre;
    }
} 