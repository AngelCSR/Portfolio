/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Principal;

import ciclo.Ciclo;
import java.text.ParseException;
import modulo.Modulo;
import profesor.Profesor;
import alumno.Alumno;

/**
 * Clase principal que contiene el método main para ejecutar la aplicación.
 * Esta clase demuestra la creación de ciclos formativos, módulos, profesores y alumnos,
 * así como la asociación entre ellos.
 * Cumple con las convenciones de nombres de Java y está documentada para JavaDOC.
 *
 * @author usutarde
 * @version 1.0
 */
public class Principal {

    /**
     * Método principal que sirve como punto de entrada para la aplicación.
     * Crea instancias de las clases Ciclo, Modulo, Profesor y Alumno,
     * las relaciona entre sí y muestra información sobre ellas.
     *
     * @param args Argumentos de la línea de comandos (no se utilizan en esta aplicación).
     * @throws ParseException Si ocurre un error al crear instancias de Alumno o Profesor.
     */
    public static void main(String[] args) throws ParseException {
        // Creamos dos ciclos formativos.
        Ciclo daw = new Ciclo(001, "Desarrollo de Aplicaciones Web");
        Ciclo dam = new Ciclo(002, "Desarrollo de Aplicaciones Multiplataforma");

        // Creamos tres módulos para el ciclo DAW (Desarrollo de Aplicaciones Web).
        Modulo SIdaw = new Modulo(483, "Sistemas Informaticos");
        Modulo BDdaw = new Modulo(484, "Bases de Datos");
        Modulo Programaciondaw = new Modulo(485, "Programacion");

        // Insertamos los módulos creados en la lista de módulos del ciclo DAW.
        daw.insertarModulo(SIdaw);
        daw.insertarModulo(BDdaw);
        daw.insertarModulo(Programaciondaw);

        // Creamos un profesor.
        Profesor prof1 = new Profesor("Juan", "Pérez", "Pérez", 12345678, 'Z');

        // Asociamos el profesor a dos módulos del ciclo DAW.
        prof1.insertarModulo(BDdaw);
        prof1.insertarModulo(SIdaw);
 
        // Creamos dos alumnos.
        Alumno alu1 = new Alumno("Ana", "Gómez", "Torres", 32145456, 'N', 55544444, "C/ Melancolia");
        Alumno alu2 = new Alumno("Paco", "Perez", "Molina", 32154456, 'L', 55544444, "C/ Rosendo");

        // Matriculamos los alumnos en el ciclo DAW.
        daw.insertarAlumno(alu2);
        daw.insertarAlumno(alu1);

        // Mostramos el listado de módulos del ciclo DAW.
        daw.mostrarModulo();

        // Mostramos el listado de alumnos matriculados en el ciclo DAW.
        daw.mostrarAlumno();
    }
}