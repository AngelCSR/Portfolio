/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dni;

/**
 * Representa un Documento Nacional de Identidad (DNI) español,
 * con su número y letra de control.
 * Cumple con las convenciones de nombres de Java y está documentada para JavaDOC.
 *
 * @author Ángel Campo
 * @version 1.0
 */
public class Dni {

    /**
     * Número del DNI (sin la letra).
     */
    private int numero;

    /**
     * Letra de control del DNI.
     */
    private char letra;

    /**
     * Constructor de la clase {@code Dni}. Valida el número y la letra proporcionados.
     *
     * @param numero Número del DNI (sin la letra).
     * @param letra  Letra de control del DNI.
     * @throws IllegalArgumentException Si el número del DNI no es válido.
     * @throws IllegalArgumentException Si la letra del DNI no es válida para el número proporcionado.
     */
    public Dni(int numero, char letra) {
        if (!esNumeroValido(numero)) {
            throw new IllegalArgumentException("El numero del DNI no es valido.");
        }
        if (!esLetraValida(numero, Character.toUpperCase(letra))) { // Convertir la letra a mayúscula para la validación
            throw new IllegalArgumentException("La letra del DNI no es valida.");
        }
        this.numero = numero;
        this.letra = Character.toUpperCase(letra); // Almacenar la letra en mayúscula
    }

    /**
     * Obtiene el número del DNI.
     *
     * @return El número del DNI.
     */
    public int getNumero() {
        return numero;
    }

    /**
     * Establece el número del DNI.
     *
     * @param numero El nuevo número del DNI.
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * Obtiene la letra del DNI.
     *
     * @return La letra del DNI.
     */
    public char getLetra() {
        return letra;
    }

    /**
     * Establece la letra del DNI.
     *
     * @param letra La nueva letra del DNI.
     */
    public void setLetra(char letra) {
        this.letra = Character.toUpperCase(letra); // Almacenar la letra en mayúscula
    }

    /**
     * Valida si el número del DNI tiene un formato válido (mayor que 0 y hasta 8 dígitos).
     *
     * @param numero El número del DNI a validar.
     * @return {@code true} si el número es válido, {@code false} en caso contrario.
     */
    private boolean esNumeroValido(int numero) {
        return numero > 0 && String.valueOf(numero).length() <= 8;
    }

    /**
     * Valida si la letra del DNI es correcta para el número proporcionado
     * según el algoritmo estándar de cálculo de la letra del DNI español.
     *
     * @param numero El número del DNI.
     * @param letra  La letra del DNI a validar (se compara en mayúsculas).
     * @return {@code true} si la letra es válida para el número, {@code false} en caso contrario.
     */
    private boolean esLetraValida(int numero, char letra) {
        if (!Character.isLetter(letra)) {
            return false;
        }

        String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
        int indice = numero % 23;
        char letraCalculada = letras.charAt(indice);

        return Character.toUpperCase(letra) == letraCalculada;
    }

    /**
     * Devuelve una representación en cadena del objeto {@code Dni} en el formato "00000000-A".
     *
     * @return Una cadena formateada del número y la letra del DNI.
     * @see String#format(String, Object...)
     */
    @Override
    public String toString() {
        return String.format("%08d-%c", numero, letra); // Formato 00000000-A
    }
}