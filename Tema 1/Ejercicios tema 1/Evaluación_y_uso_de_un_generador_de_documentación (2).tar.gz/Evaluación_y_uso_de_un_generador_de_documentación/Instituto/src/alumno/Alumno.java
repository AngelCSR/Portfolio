/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alumno;

import ciclo.Ciclo;
import dni.Dni;
import java.text.ParseException;
import persona.Persona;

/**
 * La clase {@code Alumno} representa a un estudiante, extendiendo la funcionalidad de la clase {@link Persona}
 * para incluir información específica del alumno como teléfono, dirección y el ciclo formativo que cursa.
 *
 * @author usutarde
 * @version 1.0
 */
public class Alumno extends Persona {
    /**
     * Número de teléfono del alumno.
     */
    private int telefono;
    /**
     * Dirección de residencia del alumno.
     */
    private String direccion;
    /**
     * Ciclo formativo que cursa el alumno.
     */
    private Ciclo ciclo;

    /**
     * Constructor de la clase {@code Alumno}.
     *
     * @param nombre    Nombre del alumno.
     * @param apellido1 Primer apellido del alumno.
     * @param apellido2 Segundo apellido del alumno.
     * @param dni       Objeto {@link Dni} que representa el DNI del alumno.
     * @param telefono  Número de teléfono del alumno.
     * @param direccion Dirección de residencia del alumno.
     * @param ciclo     Objeto {@link Ciclo} que representa el ciclo formativo del alumno.
     * @throws ParseException Si ocurre un error al parsear la información relacionada con la persona.
     */
    public Alumno(String nombre, String apellido1, String apellido2, Dni dni,
            int telefono, String direccion, Ciclo ciclo) throws ParseException {
        
        super(nombre, apellido1, apellido2, dni);
        this.telefono = telefono;
        this.direccion = direccion;
        this.ciclo = ciclo;
    }

    /**
     * Constructor de la clase {@code Alumno} que permite crear un alumno proporcionando directamente
     * el número y la letra del DNI.
     *
     * @param nombre      Nombre del alumno.
     * @param apellido1   Primer apellido del alumno.
     * @param apellido2   Segundo apellido del alumno.
     * @param numeroDni   Número del DNI del alumno.
     * @param letraDni    Letra del DNI del alumno.
     * @param ciclo       Objeto {@link Ciclo} que representa el ciclo formativo del alumno.
     * @param telefono    Número de teléfono del alumno.
     * @param direccion   Dirección de residencia del alumno.
     * @throws ParseException Si ocurre un error al parsear la información relacionada con la persona.
     */
    public Alumno(String nombre, String apellido1, String apellido2, int numeroDni, char letraDni,
            Ciclo ciclo, int telefono, String direccion) throws ParseException {
        super(nombre, apellido1, apellido2, numeroDni, letraDni);
        this.telefono = telefono;
        this.direccion = direccion;
        this.ciclo = ciclo;
    }

    /**
     * Constructor de la clase {@code Alumno} que permite crear un alumno proporcionando directamente
     * el número y la letra del DNI, sin especificar el ciclo.
     *
     * @param nombre      Nombre del alumno.
     * @param apellido1   Primer apellido del alumno.
     * @param apellido2   Segundo apellido del alumno.
     * @param numeroDni   Número del DNI del alumno.
     * @param letraDni    Letra del DNI del alumno.
     * @param telefono    Número de teléfono del alumno.
     * @param direccion   Dirección de residencia del alumno.
     * @throws ParseException Si ocurre un error al parsear la información relacionada con la persona.
     */
    public Alumno(String nombre, String apellido1, String apellido2, int numeroDni, char letraDni, int telefono, String direccion) throws ParseException {
        super(nombre, apellido1, apellido2, numeroDni, letraDni);
        this.telefono = telefono;
        this.direccion = direccion;
    }

    /**
     * Obtiene el número de teléfono del alumno.
     *
     * @return El número de teléfono del alumno.
     */
    public int getTelefono() {
        return telefono;
    }

    /**
     * Establece el número de teléfono del alumno.
     *
     * @param telefono El nuevo número de teléfono del alumno.
     */
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    /**
     * Obtiene la dirección de residencia del alumno.
     *
     * @return La dirección del alumno.
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Establece la dirección de residencia del alumno.
     *
     * @param direccion La nueva dirección del alumno.
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Obtiene el ciclo formativo que cursa el alumno como una cadena.
     *
     * @return El nombre del ciclo formativo.
     */
    public String getCiclo() {
        return ciclo != null ? ciclo.toString() : "Sin ciclo asignado";
    }

    /**
     * Establece el ciclo formativo que cursa el alumno.
     *
     * @param ciclo El nuevo ciclo formativo del alumno.
     */
    public void setCiclo(Ciclo ciclo) {
        this.ciclo = ciclo;
    }

    /**
     * Devuelve una representación en cadena del objeto {@code Alumno}.
     * Incluye la información de la superclase {@link Persona} y los atributos propios del alumno.
     *
     * @return Una cadena que representa al alumno.
     * @see Persona#toString()
     * @see #getTelefono()
     * @see #getDireccion()
     * @see #getCiclo()
     */
    @Override
    public String toString() {
        return super.toString() + ", telefono: " + telefono + ", direccion: " + direccion +
                (ciclo != null ? ", ciclo: " + ciclo.toString() : ", ciclo: Sin asignar");
    }
} 